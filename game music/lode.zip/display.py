#
#  d i s p l a y . p y
#
import sys, boards, copy
from   graphics import *

if "win" in sys.platform : clearScreen = "cls"
else                     : clearScreen = "clear"  # unix, linux or mac

win = GraphWin("x", 1, 1) # virtually invisible
board  = []
screen = []

def setBoard(n) :
    global board
    board = copy.copy(boards.boards[n])

def getSpot (row,col) :
    'return board value ("_","|"," ") for row,col'
    try     : return board[row][col]
    except  : return ' '

def setSpot (row,col,newchar) :
    'update board value at row,col with newchar'
    try :
        l = board[row]
        l = l[:col]+newchar+l[col+1:]
        board[row] = l
    except : pass

def writeBoard() :
    global board, screen
    screen = copy.copy(board)

def writeScreen(row,col,chars) :
    'write chars to screen at row,col'
    while len(screen) <= row : screen.append('')
    nchars = len(chars)
    sofar = len(screen[row])
    if col > sofar : screen[row] += " "*(col-sofar)
    first = screen[row][:col]
    third = screen[row][(col+nchars):]
    screen[row] = first+chars+third

def sendScreen() :
    os.system(clearScreen)
    for row in screen :
        print("-"+row)

