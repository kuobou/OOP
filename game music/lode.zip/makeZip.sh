zip lode.zip *.py *.sh
