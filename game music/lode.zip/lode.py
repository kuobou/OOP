#!/usr/bin/env python
#
#   l o d e . p y
#
import random, time
from   display import *

class Player :
    def setDirection (self, ch) : pass

    def move (self) :
        global inPlay, you, players
        spot  = getSpot(self.row,self.col)
        lspot = getSpot(self.row,self.col-1)
        rspot = getSpot(self.row,self.col+1)
  
        horz,vert = self.dir
        writeScreen(self.row,self.col,spot)
        if   spot == '_' : self.col += horz  # catwalk left/right
        elif spot == '|' :
            self.row -= vert             # by up/down arrow
            self.col += horz             # may jump off the ladder
        elif spot == ' ' : self.row += 1 # always fall in air
        writeScreen(self.row,self.col,self.face)
        if self.row > 23 :
            if self.face == '^' : inPlay = False  # You have plunged
            else : players.remove(self)

class You(Player) :
    def __init__ (self, row=1, col=10, face='^') :
        self.row = row; self.col = col; self.face=face
        self.dir = (0,0); self.score=0; self.cmd =None

    def setDirection (self, ch) :
        here = getSpot(self.row,self.col)
        if here == '*' :
            self.score += 10
            setSpot(self.row,self.col,"_")
            writeScreen(self.row,self.col,"_")   # update the screen

        if ch == 'Up' and here == '|' : self.dir=( 0, 1)
        if ch == 'Down' : self.dir=( 0,-1)
        if ch == 'Right': self.dir=( 1, 0)
        if ch == 'Left' : self.dir=(-1, 0)
        if ch == 'a' : burn(self.row, self.col-1); self.dir=(0,0)
        if ch == 's' : burn(self.row, self.col+1); self.dir=(0,0)

class Robot(Player) :
    def __init__ (self, row=1, col=12, Face='&') :
        self.row = row; self.col = col; self.face=Face
        self.dir = (0,0)

    def move (self) :
        global clock
        if clock%2 == 0 : Player.move(self)

    def setDirection (self, ch) :
        global inPlay, you
        # did we tag him?
        if you.row == self.row and you.col == self.col : inPlay=False
        # same level. run toward you
        if self.row == you.row :
            if self.col > you.col : self.dir=(-1,0) # left
            if self.col < you.col : self.dir=( 1,0) # right
        else :
            me = getSpot(self.row,self.col)  # where am I
            if me == "|" : # on a ladder
                if self.row > you.row : self.dir=(0, 1) # up
                if self.row < you.row : self.dir=(0,-1) # down
    
def burn (row,col) :
    "Burn a hole in the catwalk at row,col"
    setSpot(row,col," ")       # set the board
    writeScreen(row,col," ")   # update the screen

def main ():
    try :
        setBoard(0)
        playGame()
    finally:
        win.close()  

def playGame() :
    global clock, inPlay, you, players
    writeBoard ()
    you = You()
    players = [you]
    clock = 0
    cmd   = None
    inPlay = True
    while inPlay :
        clock += 1
        if clock > 40 and len(players) < 3 :
            players.append(Robot(col=int(random.random()*40+5)))
        sendScreen()
        time.sleep(.1)
        keys = win.checkKey()
        if keys : cmd = keys #; writeScreen (21,0,'Command: %-6s' % cmd)
        for player in players :
            player.setDirection(cmd)
            player.move()
        writeScreen (20,0,'Score: %d. Cmd: %s    ' % (you.score,cmd))
    writeScreen (21,0,'Game over. Score: %d\n'     %  you.score)

if __name__ == "__main__" : main()
